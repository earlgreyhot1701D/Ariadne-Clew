# diffcheck.py
# Local QA utility to check diffs between file versions
